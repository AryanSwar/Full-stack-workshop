package P1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Delete {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Configuration c=new Configuration();
c.configure("hibernate.cfg.xml");
SessionFactory sf=c.buildSessionFactory();
Session s=sf.openSession();
Transaction tx=s.beginTransaction();
Student st=s.load(Student.class,4);

//st.setName("Kalu");
//st.setCourse("B.Tech (CSE)");
s.delete(st);
tx.commit();
s.close();
	}

}
