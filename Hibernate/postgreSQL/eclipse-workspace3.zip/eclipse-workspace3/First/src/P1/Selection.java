package P1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.*;
import org.hibernate.query.Query;
public class Selection {

	public static void main(String[] args) {
		Configuration c=new Configuration();
		c.configure("hibernate.cfg.xml");
		SessionFactory sf=c.buildSessionFactory();
		Session s=sf.openSession();
		Transaction tx=s.beginTransaction();
		Query q=s.createQuery("from Student where name=:naam");
		q.setParameter("naam","ARYAN");
		List<Student> l= q.list();
		tx.commit();
		Iterator<Student> i=l.iterator();
		while(i.hasNext()) {
			Student st=i.next();
			String name=st.getName();
			String course=st.getCourse();
			int roll=st.getRoll();
			System.out.println("Roll="+roll+"  Name= "+name+"   Course="+course);
			
		}
		
		
		
		
		
		
		
		

	}

}
