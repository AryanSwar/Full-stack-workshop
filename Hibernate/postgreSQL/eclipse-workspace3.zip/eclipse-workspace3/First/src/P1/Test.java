package P1;
import org.hibernate.Transaction;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
public class Test {
	public static void main(String args[])
	{System.out.println("before conf");
		Configuration c= new Configuration();
		System.out.println("after conf");
		c.configure("hibernate.cfg.xml");
		SessionFactory sf=c.buildSessionFactory();
		Session s2=sf.openSession();
		Transaction tx=s2.beginTransaction();
		Student s=new Student();
		s.setCourse("B.Tech");
		s.setName("Ram");
		s.setRoll(2);
		s2.save(s);
		
		tx.commit();
	}
}