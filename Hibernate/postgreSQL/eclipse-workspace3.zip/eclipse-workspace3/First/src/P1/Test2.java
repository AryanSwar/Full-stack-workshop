package P1;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder; 
public class Test2 {
	public static void main(String a[])
	{
		System.out.println("configuration ");
		//Configuration c=new Configuration();
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build(); 
		System.out.println("configuration2 ");
		Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
		System.out.println("configuration ");
		SessionFactory sf = meta.getSessionFactoryBuilder().build(); 
		
		//c.configure("hibernate.cfg.xml");
		//SessionFactory sf=sf.buildSessionFactory();
		Session s2=sf.openSession();
		Transaction tx=s2.beginTransaction();
		Student s=new Student();
		s.setCourse("M.Tech");
		s.setName("Kesari kallu");
		s.setRoll(4);
		s2.save(s);
		
		tx.commit();
	}

}