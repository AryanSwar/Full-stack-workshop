package P1;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class SessionUtility {
	private static ThreadLocal<Session> ss=new ThreadLocal<Session>();
	private static  SessionFactory sf;
	private SessionUtility(){}
	static {
		
		Configuration c=new Configuration();
		//System.out.println("after configuration");
		c.configure("hibernate.cfg.xml");
		//System.out.println("after configuration 2");
		 sf=c.buildSessionFactory();//Thread safe
		 System.out.println("after Session Factory");
	}
static Session getSession()
{  
	Session s=ss.get();
if(s==null)
 s=	sf.openSession();
	return s;
	}
static void closeSession()
{
	Session s=ss.get();
	if(s!=null)
		s=null;
	}

}
